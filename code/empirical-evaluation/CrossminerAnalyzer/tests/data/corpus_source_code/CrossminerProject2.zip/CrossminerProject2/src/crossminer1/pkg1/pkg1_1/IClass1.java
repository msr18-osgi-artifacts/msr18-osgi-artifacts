package crossminer1.pkg1.pkg1_1;

public interface IClass1 {
	
	public void method1();
	public String method2();
	public int method3();
	
}
