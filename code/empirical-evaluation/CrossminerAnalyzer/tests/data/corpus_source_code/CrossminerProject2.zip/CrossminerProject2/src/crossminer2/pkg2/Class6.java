package crossminer2.pkg2;

import crossminer2.pkg2.pkg2_1.Class3;
import crossminer2.pkg2.pkg2_2.Class4;
import crossminer2.pkg2.pkg2_2.IClass4;
import crossminer2.pkg2.pkg2_3.Class5;

public class Class6 {
	private Class3 class3;
	private IClass4 class4;
	private Class5 class5;
	
	public Class6() {
		class3 = new Class3();
		class4 = new Class4(42);
		class5 = new Class5();
	}
	
	public Class3 method1() {
		return class3;
	}
	
	public IClass4 method2() {
		return class4;
	}
	
	public Class5 method3() {
		return class5;
	}
}
