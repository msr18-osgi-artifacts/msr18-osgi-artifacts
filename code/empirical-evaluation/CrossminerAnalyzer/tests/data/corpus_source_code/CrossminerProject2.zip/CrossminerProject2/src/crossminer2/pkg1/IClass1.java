package crossminer2.pkg1;

public interface IClass1 {
	public boolean method1(String val);
}
