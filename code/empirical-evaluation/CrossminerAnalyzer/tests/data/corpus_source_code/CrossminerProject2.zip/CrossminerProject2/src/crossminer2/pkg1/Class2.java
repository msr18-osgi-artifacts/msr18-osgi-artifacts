package crossminer2.pkg1;

import crossminer1.pkg1.pkg1_1.IClass1;
import crossminer1.pkg1.pkg1_1.Class1;

public class Class2 {
	public IClass1 class1;
	
	public Class2() {
		class1 = new Class1();
	}
}
