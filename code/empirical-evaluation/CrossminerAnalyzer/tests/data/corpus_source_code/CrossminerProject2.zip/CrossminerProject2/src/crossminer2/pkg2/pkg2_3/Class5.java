package crossminer2.pkg2.pkg2_3;

import crossminer3.pkg3.Class4;

public class Class5 {
	private Class4 class4;
	
	public Class5() {
		class4 = new Class4();
	}
	
	public void method1() {
		class4.method1("sweet home");
	}
}
