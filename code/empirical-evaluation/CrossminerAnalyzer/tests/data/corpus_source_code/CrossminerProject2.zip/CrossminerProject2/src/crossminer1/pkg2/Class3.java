package crossminer1.pkg2;

public class Class3 {
	private int int1;
	private int int2;
	private Class4 class4;
	
	public Class3() {
		int1 = 0;
		int2 = 1;
		class4 = new Class4();
	}
	
	public class Class3Internal {
		private int int1;
		
		public Class3Internal() {
			int1 = 10;
		}
		
		public int method1() {
			return int1;
		}
	}
}
