package crossminer2.pkg2.pkg2_2;

import crossminer3.pkg1.Class1;
import crossminer3.pkg2.Class3;
import crossminer3.pkg2.IClass3;

public class Class4 implements IClass4 {
	private int int1;
	private Class1 class1;
	
	public Class4(int int1) {
		this.int1 = int1;
		this.class1 = new Class1();
	}
	
	@Override
	public IClass3 method1() {
		return new Class3();
	}

	@Override
	public int method2() {
		return method3();
	}
	
	private int method3() {
		return int1 * int1;
	}
}
