package crossminer2.pkg1;

public class Class1 implements IClass1 {
	public final static String MSG = "7 rules!";
	
	@Override
	public boolean method1(String val) {
		return (val.equals(MSG)) ? true : false;
	}
	
}
