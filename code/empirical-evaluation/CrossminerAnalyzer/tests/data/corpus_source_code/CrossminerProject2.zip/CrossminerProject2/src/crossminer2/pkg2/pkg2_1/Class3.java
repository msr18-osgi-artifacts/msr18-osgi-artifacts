package crossminer2.pkg2.pkg2_1;

public class Class3 extends Class3Parent {
	public Class3() {
		super("Hello dad!");
	}
}
