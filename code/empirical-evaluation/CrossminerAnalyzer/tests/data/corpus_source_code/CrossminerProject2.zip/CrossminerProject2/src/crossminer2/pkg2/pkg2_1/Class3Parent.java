package crossminer2.pkg2.pkg2_1;

public class Class3Parent {
	protected final static String MSG = "I am happy to say, hello world!";
	private String string1;
	
	public Class3Parent() {
		string1 = MSG;
	}
	
	public Class3Parent(String string1) {
		this.string1 = string1;
	}
	
	public String method1() {
		return string1;
	}
	
	protected String method2() {
		return (string1.equals(MSG)) ? MSG + " What about you?" : string1;
	}
}
