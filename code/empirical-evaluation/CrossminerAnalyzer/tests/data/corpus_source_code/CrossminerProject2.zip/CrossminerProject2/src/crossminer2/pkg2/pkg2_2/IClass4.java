package crossminer2.pkg2.pkg2_2;

import crossminer3.pkg2.IClass3;

public interface IClass4 {
	
	public IClass3 method1();
	public int method2();
	
}
