package crossminer1.pkg3;

public class Class5 implements IClass5 {
	
	private int int1;
	private String string1;
	
	public Class5() {
		int1 = 0;
		string1 = "Hello world!";
	}

	@Override
	public int method1() {
		return int1 + 1;
	}

	@Override
	public String method2() {
		return string1;
	}
}
