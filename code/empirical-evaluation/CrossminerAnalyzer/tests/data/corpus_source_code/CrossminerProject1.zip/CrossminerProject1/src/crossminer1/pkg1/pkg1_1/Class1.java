package crossminer1.pkg1.pkg1_1;

import crossminer1.pkg3.Class5;
import crossminer1.pkg3.IClass5;

public class Class1 implements IClass1 {

	private IClass5 class5;
	
	public Class1() {
		class5 = new Class5();
	}
	
	@Override
	public void method1() {
		System.out.println("This is method 1.");
	}

	@Override
	public String method2() {
		String val = class5.method2() + " It is me";
		return val;
	}

	@Override
	public int method3() {
		return method4(class5.method1());
	}
	
	private int method4 (int val) {
		return val * 10;
	}
}
