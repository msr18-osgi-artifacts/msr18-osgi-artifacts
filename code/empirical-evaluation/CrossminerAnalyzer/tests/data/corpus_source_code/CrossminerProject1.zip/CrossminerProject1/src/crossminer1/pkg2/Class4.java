package crossminer1.pkg2;

public class Class4 {
	private boolean bool1;
	private boolean bool2;
	
	public Class4() {
		bool1 = false;
		bool2 = false;
	}
	
	public boolean method1() {
		if(bool2) {
			return bool2;
		}
		else {
			return method2();
		}
	}
	
	private boolean method2() {
		return (bool1) ? !bool1: bool1;
	}
}
