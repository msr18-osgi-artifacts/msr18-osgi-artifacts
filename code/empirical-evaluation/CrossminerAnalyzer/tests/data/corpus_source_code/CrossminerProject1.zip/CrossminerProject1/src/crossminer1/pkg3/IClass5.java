package crossminer1.pkg3;

public interface IClass5 {
	public int method1();
	public String method2();
}
