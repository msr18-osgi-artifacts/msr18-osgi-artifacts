package crossminer1.pkg1.pkg1_2;

public class Class2Parent {
	private int int1;
	
	public Class2Parent(int int1) {
		this.int1 = int1;
	}
	
	protected double method1() {
		return int1 + 3.4;
	}
}
