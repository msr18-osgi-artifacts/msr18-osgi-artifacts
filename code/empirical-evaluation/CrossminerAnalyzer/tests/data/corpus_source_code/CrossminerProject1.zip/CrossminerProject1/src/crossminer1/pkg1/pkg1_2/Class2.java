package crossminer1.pkg1.pkg1_2;

public class Class2 extends Class2Parent {

	public Class2(int int1) {
		super(int1 + 10);
	}

}
