package crossminer3.pkg2;

public interface IClass3 {
	
	public void method2();
	public boolean method3();
	
}
