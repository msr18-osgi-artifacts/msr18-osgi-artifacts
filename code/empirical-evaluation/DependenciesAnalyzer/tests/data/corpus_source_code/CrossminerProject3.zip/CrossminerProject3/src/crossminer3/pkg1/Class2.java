package crossminer3.pkg1;

import crossminer1.pkg1.pkg1_1.IClass1;
import crossminer1.pkg1.pkg1_1.Class1;

public class Class2 {
	private IClass1 class1;
	
	public Class2() {
		class1 = new Class1();
	}
	
	public IClass1 method1() {
		return class1;
	}
}
