package crossminer3.pkg2;

public class Class3 extends Class3Parent implements IClass3 {
	private boolean bool1;
	
	public Class3() {
		super();
		bool1 = true;
	}
	
	@Override
	public void method2() {
		System.out.println("Hello other world!");
	}

	@Override
	public boolean method3() {
		return !bool1;
	}

}
