package crossminer3.pkg3;

public class Class4 {

	public void method1(String val) {
		System.out.println("Hello " + val + "!");
	}
	
	public class Class4Internal {
		private int int1;
		private String string1;
		
		public Class4Internal(int int1, String string1) {
			this.int1 = int1;
			this.string1 = string1;
		}
	}
}
