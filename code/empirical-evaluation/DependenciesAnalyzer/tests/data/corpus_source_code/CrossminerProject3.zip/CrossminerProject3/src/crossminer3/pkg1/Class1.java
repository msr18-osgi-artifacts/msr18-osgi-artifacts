package crossminer3.pkg1;

import crossminer1.pkg3.Class5;
import crossminer1.pkg3.IClass5;

public class Class1 {
	private IClass5 class5;
	private int int1;
	
	public Class1() {
		class5 = new Class5();
	}
	
	public String method1() {
		return class5.method2();
	}
	
	public int method2() {
		return method3(class5.method1());
	}
	
	private int method3(int val) {
		return Math.max(val, int1);
	}
}
