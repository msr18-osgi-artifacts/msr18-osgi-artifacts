package crossminer3.pkg2;

public class Class3Parent {
	private String string1;
	
	public Class3Parent() {
		string1 = "This is me again.";
	}
	
	protected String method1() {
		return string1;
	}
}
